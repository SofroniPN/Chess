package Chess;

public class chess {
	    
	    public BoardFrame boardframe;
	    public static void main(String[] args) {
	        chess chess_ = new chess();
	        chess_.boardframe = new BoardFrame();
	        chess_.boardframe.setVisible(true);
	        
	    }
	
}
