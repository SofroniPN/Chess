package Chess.pieces;
import Chess.Board;


public class Bishop extends Piece {

    public Bishop(int x, int y, boolean is_white, String file_path, Board board)
    {
        super(x,y,is_white,file_path, board);
    }
    
 
    public boolean canMove(int destination_x, int destination_y)
    {
    Piece possiblePiece = board.getPiece(destination_x, destination_y);
    	   
    if(possiblePiece != null)//if the piece is not on the board the you can choose its movement
    {
    if(possiblePiece.isWhite() && this.isWhite())//for that piece to not kill their own
    {
    return false;
    }
    if(possiblePiece.isBlack() && this.isBlack())//for that piece to not kill their own
    {
    return false;
    }
    }
    if(this.getX() == destination_x || this.getY() == destination_y)
    {
   	return false;
   	}
  
    
    String direction = "";
    if(destination_y > this.getY() && destination_x > this.getX())  //predicting the movement of the piece (down-right)
    {
    direction = "down-right";
    }
    if(destination_y < this.getY() && destination_x < this.getX() ) //predicting the movement of the piece (up-left)
    {
    direction = "up-left";
    }
    if(destination_y < this.getY() && destination_x > this.getX()) //predicting the movement of the piece (up-right)
    {
    direction = "up-right";
    }
    if(destination_y > this.getY() && destination_x < this.getX()) //predicting the movement of the piece (down-left)
    {
    direction = "down-left";
    }
    if(direction.equals("down-right"))//function if you choose to move the piece down-right
    {
    int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination 
    int spaces_to_move2 = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination 
    for(int i = 1; i < spaces_to_move; i++)
    {
    for(int j = 1; j < spaces_to_move2; j++) {
    Piece p = board.getPiece(this.getX() + i, this.getY() + j);//calculating current space at this row and column at its down-right
    if (p != null)// if the piece can't move that way than it will not move
    {
    return false;
    }
    }
    }
    }
    if(direction.equals("up-left"))//function if you choose to move the piece up-left
    {
        	   int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination 
              	int spaces_to_move2 = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination 
              	for(int i = 1; i < spaces_to_move; i++)
              	{
              		for(int j = 1; j < spaces_to_move2; j++) {
              		Piece p = board.getPiece(this.getX() - i, this.getY() - j);//calculating current space at this row and column  at its up-left
              		if (p != null)// if the piece can't move that way than it will not move
              		{
              			return false;
              		}
              		}
              	}
           }
           if(direction.equals("up-right"))//function if you choose to move the piece up-right
           {
           	int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination 
           	int spaces_to_move2 = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination 
           	for(int i = 1; i < spaces_to_move; i++)
           	{
           		for(int j = 1; j < spaces_to_move2; j++) {
           		Piece p = board.getPiece(this.getX() + i, this.getY() - j);//calculating current space at this row and column  at its up-right
           		if (p != null)// if the piece can't move that way than it will not move
           		{
           			return false;
           		}
           		}
           	}
           }
           if(direction.equals("down-left"))//function if you choose to move the piece down-left
           {
        	   int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination 
              	int spaces_to_move2 = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination 
              	for(int i = 1; i < spaces_to_move; i++)
              	{
              		for(int j = 1; j < spaces_to_move2; j++) {
              		Piece p = board.getPiece(this.getX() - i, this.getY() + j);//calculating current space at this row and column at its down-left
              		if (p != null)// if the piece can't move that way than it will not move
              		{
              			return false;
              		}
              		}
              	}
           }
          
        return true;
    }
}