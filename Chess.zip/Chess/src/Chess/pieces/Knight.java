package Chess.pieces;
import Chess.Board;


public class Knight extends Piece {

    public Knight(int x, int y, boolean is_white, String file_path, Board board)
    {
        super(x,y,is_white,file_path, board);
    }
    
 
    public boolean canMove(int destination_x, int destination_y)
    {
    	Piece possiblePiece = board.getPiece(destination_x, destination_y);
    	   
    	   if(possiblePiece != null)//if the piece is not on the board the you can choose its movement
    	   {
    		   if(possiblePiece.isWhite() && this.isWhite())//for that piece to not kill their own
    		   {
    			   return false;
    		   }
    		   if(possiblePiece.isBlack() && this.isBlack())//for that piece to not kill their own
    		   {
    			   return false;
    		   }
    	   }
    	   if(Math.abs(destination_x - getX()) == 2 && Math.abs(destination_y - getY()) == 1){//movement in "Г"
   			return true;
   		}
   		
   		if(Math.abs(destination_x - getX()) == 1 && Math.abs(destination_y - getY()) == 2){//movement in "Г"
   			return true;
   		}
   		
   		return false;
   	

        
        
    }
}