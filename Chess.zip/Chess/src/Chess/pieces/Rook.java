package Chess.pieces;
import Chess.Board;


public class Rook extends Piece {

    public Rook(int x, int y, boolean is_white, String file_path, Board board)
    {
        super(x,y,is_white,file_path, board);
    }
    
 
    public  boolean canMove(int destination_x, int destination_y)
    {
    	
   Piece possiblePiece = board.getPiece(destination_x, destination_y);
   
   if(possiblePiece != null)//if the piece is not on the board the you can choose its movement
   {
	   if(possiblePiece.isWhite() && this.isWhite()) //for that piece to not kill their own
	   {
		   return false;
	   }
	   if(possiblePiece.isBlack() && this.isBlack())//for that piece to not kill their own
	   {
		   return false;
	   }
   }
        if(this.getX() != destination_x && this.getY() != destination_y) //Declining diagonal movement
        {
        	return false;
        }
        
        String direction = "";
        if(destination_y > this.getY()) //predicting the movement of the piece (down)
        {
        	direction = "down";
        }
        if(destination_y < this.getY())//predicting the movement of the piece (up)
        {
        	direction = "up";
        }
        if(destination_x > this.getX())//predicting the movement of the piece (right)
        {
        	direction = "right";
        }
        if(destination_x < this.getX())//predicting the movement of the piece (left)
        {
        	direction = "left";
        }
        if(direction.equals("down"))//function if you choose to move the piece down
        {
        	int spaces_to_move = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination to your wanted destination
        	for(int i = 1; i < spaces_to_move; i++)
        	{
        		Piece p = board.getPiece(this.getX(), this.getY() + i);//calculating current space at this row and column at its down
        		if (p != null) // if the piece can't move that way than it will not move
        		{
        			return false;
        		}
        	}
        }
        if(direction.equals("up"))//function if you choose to move the piece up
        {
        	int spaces_to_move = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination to your wanted destination
        	for(int i = 1; i < spaces_to_move; i++)
        	{
        		Piece p = board.getPiece(this.getX(), this.getY() - i);//calculating current space at this row and column  at its up
        		if (p != null)// if the piece can't move that way than it will not move
        		{
        			return false;
        		}
        	}
        }
        if(direction.equals("right"))//function if you choose to move the piece right
        {
        	int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination to your wanted destination
        	for(int i = 1; i < spaces_to_move; i++)
        	{
        		Piece p = board.getPiece(this.getX() + i, this.getY());//calculating current space at this row and column  at its right
        		if (p != null)// if the piece can't move that way than it will not move
        		{
        			return false;
        		}
        	}
        }
        if(direction.equals("left"))//function if you choose to move the piece left
        {
        	int spaces_to_move = Math.abs(destination_x - this.getX());//calculating all spaces from the current destination to your wanted destination
        	for(int i = 1; i < spaces_to_move; i++)
        	{
        		Piece p = board.getPiece(this.getX() - i, this.getY());//calculating current space at this row and column at its left
        		if (p != null)// if the piece can't move that way than it will not move
        		{
        			return false;
        		}
        	}
        }
        return true;
    }
}