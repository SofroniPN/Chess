package Chess.pieces;
import Chess.Board;


public class Pawn extends Piece {

    public Pawn(int x, int y, boolean is_white, String file_path, Board board)
    {
        super(x,y,is_white,file_path, board);
    }
    
 
    public boolean canMove(int destination_x, int destination_y)
    {
    	Piece possiblePiece = board.getPiece(destination_x, destination_y);
    	   
    	   if(possiblePiece != null)//if the piece is not on the board the you can choose its movement
    	   {
    		   if(possiblePiece.isWhite() && this.isWhite())//for that piece to not kill their own
    		   {
    			   return false;
    		   }
    		   if(possiblePiece.isBlack() && this.isBlack())//for that piece to not kill their own
    		   {
    			   return false;
    		   }
    	   }
    	   
    	   if(this.getX() != destination_x)//you cant move this on the same place as before
    	   {
           	return false;
           }
    	   int spaces_to_move = Math.abs(destination_y - this.getY());//calculating all spaces from the current destination to your wanted destination
       	for(int i = 1; i < spaces_to_move; i++)
       	{
       		Piece p = board.getPiece(this.getX(), this.getY() + i);//calculating current space at this row and column at its down
       		if (p != null)// if the piece can't move that way than it will not move
       		{
       			return false;
       		}
       	}
              

               
        return true;
    }


	public void setHasMoved(boolean b) {
	
		
	}
}